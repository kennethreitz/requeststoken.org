SELECT date, sum(count) AS downloads FROM pypi.pypi_downloads_per_day WHERE project = 'requests' GROUP BY date ORDER BY date FORMAT JSON
