#!/usr/bin/env python3
"""Recompute Requests download records without PePy (Python standard library only).

Run: python3 verify_requests.py --date 2026-10-24 --out my-check
Without --date, discover the latest day in ClickPy's daily aggregate first.
This reads the public ClickHouse/ClickPy replica, not Google BigQuery directly.
"""
import argparse
import hashlib
import json
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ENDPOINT = "https://sql-clickhouse.clickhouse.com/"
STRICT = (" SETTINGS max_execution_time=45, read_overflow_mode='throw', "
          "timeout_overflow_mode='throw', result_overflow_mode='throw', "
          "group_by_overflow_mode='throw' FORMAT JSON")


def query(name, sql, output):
    """Save SQL, original response bytes, response metadata and content hash."""
    url = ENDPOINT + "?" + urlencode({"user": "demo", "query": sql})
    (output / (name + ".sql")).write_text(sql + "\n", encoding="utf-8")
    try:
        with urlopen(Request(url, headers={"User-Agent": "Requests-download-audit/1.0"}),
                     timeout=55) as response:
            raw = response.read()
            headers = dict(response.headers)
            status = response.status
    except HTTPError as error:
        (output / (name + ".error.txt")).write_bytes(error.read())
        raise
    (output / (name + ".json")).write_bytes(raw)
    metadata = {"source_url": url, "http_status": status, "http_headers": headers,
                "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                "sha256": hashlib.sha256(raw).hexdigest()}
    (output / (name + ".meta.json")).write_text(json.dumps(metadata, indent=2))
    data = json.loads(raw)
    if data.get("exception"):
        raise RuntimeError(data["exception"])
    if data.get("rows") != len(data.get("data", [])):
        raise RuntimeError("Unexpected response row count")
    return data["data"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", help="UTC calendar day in YYYY-MM-DD format")
    parser.add_argument("--out", default="requests-check-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
    args = parser.parse_args()
    output = Path(args.out).resolve()
    output.mkdir(parents=True, exist_ok=False)
    if args.date:
        selected = date.fromisoformat(args.date)
    else:
        latest = query("latest_available_day", "SELECT max(date) AS latest_day "
                       "FROM pypi.pypi_downloads_per_day WHERE project = 'requests'" + STRICT, output)
        selected = date.fromisoformat(latest[0]["latest_day"])
    if selected >= datetime.now(timezone.utc).date():
        raise ValueError("Choose a completed UTC calendar day; the current day may be partial")
    end = selected + timedelta(days=1)
    day_sql = ("SELECT date, count() AS recorded_download_events, "
               "countIf(endsWith(filename, '.whl') OR endsWith(filename, '.tar.gz') OR "
               "endsWith(filename, '.zip')) AS distribution_file_records, "
               "countIf(filename = '') AS filename_unavailable, "
               "countIf(ci = 'true') AS ci_true, countIf(ci = 'false') AS ci_false, "
               "countIf(ci = 'unknown') AS ci_unknown FROM pypi.pypi "
               f"WHERE project = 'requests' AND date = '{selected.isoformat()}' GROUP BY date" + STRICT)
    day_rows = query("day", day_sql, output)
    if len(day_rows) != 1:
        raise RuntimeError("No recorded data for the requested day; do not label this as zero downloads")
    total_sql = ("SELECT count() AS recorded_download_events FROM pypi.pypi "
                 f"WHERE project = 'requests' AND date < '{end.isoformat()}'" + STRICT)
    total_rows = query("historical", total_sql, output)
    if len(total_rows) != 1:
        raise RuntimeError("Expected exactly one historical-count row")
    stats = {"package": "requests", "source": "ClickPy public replica of PyPI logs",
             "utc_day": selected.isoformat(), "exclusive_end_utc": end.isoformat(),
             "recorded_download_events_for_day": int(day_rows[0]["recorded_download_events"]),
             "historical_recorded_download_events_through_day": int(total_rows[0]["recorded_download_events"]),
             "qualifications": ["Calendar day, not a live rolling 24-hour window.",
                                "Historical total covers records available in this replica, not a complete lifetime census.",
                                "Includes automated downloads and mirrors; downloads are not unique users.",
                                "Historical PyPI recording methodology changed on 2026-08-24.",
                                "Later backfills, ingestion and corrections can change counts."]}
    (output / "summary.json").write_text(json.dumps(stats, indent=2))
    print(json.dumps(stats, indent=2))
    print("Saved original server responses and reproduction links in:", output)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Verification failed; no successful claim should be inferred:", error, file=sys.stderr)
        sys.exit(1)
