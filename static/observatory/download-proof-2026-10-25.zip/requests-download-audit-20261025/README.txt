REQUESTS DOWNLOAD EVIDENCE — 25 OCTOBER 2026

This evidence package was assembled from direct, read-only SQL queries to
ClickHouse's public ClickPy database. No PePy count was used as an input.
It is an independent computation on a third-party replica of official PyPI
records, NOT an independent download logging system and NOT a direct BigQuery run.

CONFIRMED RESULTS

1. UTC calendar day 2026-10-24: 34,524,196 recorded download events.
   WIB window: 24 October 07:00 through 25 October 07:00, end exclusive.
   The entire observed count has a .whl, .tar.gz or .zip filename.
   A separately grouped installer query sums to exactly the same count.
   Latest date discovery used the per-day aggregate; counts use the base table.
   This is the latest recorded calendar day, not a live rolling 24-hour window.

2. Historical base-table count: 39,530,831,689 recorded download events.
   Query interval: 2016-01-22 inclusive through 2026-10-25 exclusive.
   Unbounded base-table count returned the same result.
   Earliest recorded date observed: 2016-01-22.
   There are 79 missing calendar dates in that span; the base table contains
   zero rows for those dates as verified by raw_gap_check.json.
   Therefore this is NOT a complete lifetime census from Requests' first release.

3. Source comparison for 2026-10-23:
   ClickHouse raw installer counts: 51,780,369.
   PyPI Stats with_mirrors:          51,780,369.
   PyPI Stats was still at 2026-10-23 when captured. It cannot independently
   confirm the newer 2026-10-24 observation in this package.
   Other historical days do differ; crosscheck.json includes all observed
   differences, so this audit does not claim blanket agreement between sources.

HOW TO VERIFY

Open proof_links.txt. Each URL sends a visible SELECT query directly to the
public ClickHouse server and returns JSON. The host and public read-only demo
user are published in the ClickPy source repository linked in sources.json.
These queries use throw-on-limit settings so a partial scan is not presented
as a successful complete result. The fixed dates keep the comparison window
constant, although historical corrections can change the returned number.

For the exact captured result, inspect raw_latest_day.json and
raw_historical_cutoff_verified.json. Their .meta.json companions contain the
URL, retrieval timestamp, HTTP response headers including server query IDs,
and SHA-256 of the untouched response bytes.

To recompute with Python 3 and no extra dependencies:
    python3 verify_requests.py --date 2026-10-24 --out my-independent-check

Omit --date to discover the latest available day first. Use a new output
folder on every run. The script does not use PePy and does not need a private
API key. The public database applies quotas and may be unavailable.

An official-dataset BigQuery query is included separately as
bigquery_direct_check_NOT_EXECUTED.sql. It was prepared but NOT executed:
no authenticated Google Cloud project was available. Query cost and data
freshness should be checked before running it in your own project.

MATERIAL LIMITATIONS — DO NOT OMIT WHEN MAKING CLAIMS

A. Downloads are recorded events, not unique users, companies or installations.
   CI and mirrors are included. An automated job can download the same package
   many times. Partial-content HTTP fetches may also count as a download.

B. On 2026-08-24 PyPI changed its logging to distribution artifacts only.
   Older data can include .metadata and other objects. No retroactive
   distribution-only cleanup was done for the historical total in this audit.
   See the official PyPI blog link in sources.json. Do not describe the
   historical total as 39.53 billion verified complete installs.

C. Historical completeness is limited. The observed gaps are
   2016-03-06 through 2016-05-21, plus 2019-04-26 and 2019-04-27.
   A missing recorded date is not evidence of zero real-world downloads.
   Nothing in this audit reconstructs downloads before the available records.

D. Aggregate discrepancy:
   Base-table COUNT with strict overflow checks: 39,530,831,689.
   Sum of per-day aggregate: 39,532,848,966.
   Total aggregate table: 39,534,235,309.
   Differences relative to the base table: 2,017,277
   and 3,403,620, respectively.
   The cause was not established. Claims use the lower base-table count.

E. Rejected diagnostic query:
   raw_daily_history grouped the entire base table by date. The public server
   defaults to max_rows_to_read=1,000,000,000 and read_overflow_mode=break.
   It returned only 278 dates / 1,001,358,295 records, so it is partial and
   must NOT be used as a historical total or coverage census. See diagnostics/.
   First/last-date ordered scans failed under strict limits and are likewise
   excluded. The successful historical COUNT uses strict throw-on-limit
   settings and read only about 1.35 million rows due to the engine's counting
   optimization; it did not hit the limit. Exact runtime statistics are in JSON.

FILES

summary.json — claim definitions, limitations, cross-check status and proof URLs.
raw_latest_day.* — detailed latest-day base-table query, result and metadata.
raw_historical_cutoff_verified.* — strict historical COUNT with fixed dates.
raw_total_count.* — independent unbounded base-table COUNT for comparison.
raw_compare_day.* — installer breakdowns for 23 and 24 October.
raw_gap_check.* — confirms no base-table records on 79 missing aggregate dates.
daily.* and daily_aggregate_series.csv — aggregate series, NOT a raw census.
history_summary.* / history_total_view.* — discrepant aggregates retained openly.
pypistats_overall.* / crosscheck.json — independent-provider comparison.
schema.* / raw_table_definition.* / query_limits.* — observed server context.
diagnostics/ — rejected partial or unsuccessful queries, clearly not evidence.
verify_requests.py — reusable standard-library-only checker.
SHA256SUMS.txt — hashes for file-integrity checks, not external attestation.

TIMESTAMPS

Latest-day raw response retrieved at:
2026-10-25T00:47:40.275845+00:00
Historical strict count retrieved at:
2026-10-25T00:48:58.651848+00:00

PRIMARY DOCUMENTATION AND LINKS

Python packaging documentation: official dataset and free ClickPy SQL access
https://packaging.python.org/en/latest/guides/analyzing-pypi-package-downloads/

ClickPy source, schema and published public credentials
https://github.com/ClickHouse/clickpy

ClickHouse ingestion from BigQuery and historical repairs
https://clickhouse.com/blog/clickpy-2-trillion-rows

PyPI Stats data provenance
https://pypistats.org/about

PyPI Stats update schedule and mirror/CI definitions
https://pypistats.org/faqs

PyPI recording methodology change on 2026-08-24
https://blog.pypi.org/posts/2026-08-31-download-counts/

Visual dashboard (not used as numerical input)
https://clickpy.clickhouse.com/dashboard/requests
