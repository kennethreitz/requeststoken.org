SELECT sum(count) AS total_downloads FROM pypi.pypi_downloads WHERE project = 'requests' FORMAT JSON
