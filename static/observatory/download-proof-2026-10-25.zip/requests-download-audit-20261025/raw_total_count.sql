SELECT count() AS total_download_records FROM pypi.pypi WHERE project = 'requests' SETTINGS max_execution_time=45 FORMAT JSON
