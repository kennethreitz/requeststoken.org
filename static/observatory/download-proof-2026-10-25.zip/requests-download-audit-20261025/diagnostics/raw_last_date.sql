SELECT date FROM pypi.pypi WHERE project = 'requests' ORDER BY date DESC LIMIT 1 SETTINGS max_execution_time=45, read_overflow_mode='throw' FORMAT JSON
