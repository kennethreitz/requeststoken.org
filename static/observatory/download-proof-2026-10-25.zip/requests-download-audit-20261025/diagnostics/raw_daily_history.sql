SELECT date, count() AS downloads FROM pypi.pypi WHERE project = 'requests' GROUP BY date ORDER BY date SETTINGS max_execution_time=45 FORMAT JSON
