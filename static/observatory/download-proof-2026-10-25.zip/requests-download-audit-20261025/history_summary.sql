SELECT min(date) AS first_date, max(date) AS last_date, uniqExact(date) AS days_present, sum(count) AS total_downloads FROM pypi.pypi_downloads_per_day WHERE project = 'requests' FORMAT JSON
