-- Prepared for direct verification against the official PyPI BigQuery dataset.
-- NOT EXECUTED in this audit: no authenticated Google Cloud project was available.
-- Run as GoogleSQL in your own BigQuery project. Check estimated bytes/cost first.
-- A calendar-day count is not a rolling last-24-hours count.
SELECT
  DATE(timestamp) AS utc_day,
  COUNT(*) AS recorded_file_events,
  COUNTIF(REGEXP_CONTAINS(file.filename, r'\.(whl|tar\.gz|zip)$')) AS distribution_file_events
FROM `bigquery-public-data.pypi.file_downloads`
WHERE file.project = 'requests'
  AND timestamp >= TIMESTAMP('2026-10-24 00:00:00+00')
  AND timestamp < TIMESTAMP('2026-10-25 00:00:00+00')
GROUP BY utc_day;
